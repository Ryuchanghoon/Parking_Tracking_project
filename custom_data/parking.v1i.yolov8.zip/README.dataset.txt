# parking > 2024-08-14 12:51am
https://universe.roboflow.com/physical-laborrch/parking-oijoo

Provided by a Roboflow user
License: CC BY 4.0

