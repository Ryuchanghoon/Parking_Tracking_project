# license plate > 2024-08-23 5:50am
https://universe.roboflow.com/physical-laborrch/license-plate-dfeke

Provided by a Roboflow user
License: CC BY 4.0

